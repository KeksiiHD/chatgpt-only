# Dienstübersicht Discord Bot

Ein Bot, der eine Dienstliste mit Rollen und Reaktionen verwaltet.